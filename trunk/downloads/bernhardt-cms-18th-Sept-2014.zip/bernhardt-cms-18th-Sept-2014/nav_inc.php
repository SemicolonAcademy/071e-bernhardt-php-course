<a href="index.php">Home</a>
<a href="about.php">About</a>
<a href="services.php">Services</a>	
<a href="contact.php">Contact Us</a>			
