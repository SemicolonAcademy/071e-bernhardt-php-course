<div class="left_box">
	<h4>Latest News</h4>
	<p>
		<a href="">
			Lorem ipsum dolar sit amet<br/>
			<span>this is small news content of the full news post, 
			<?php echo date("Y/m/d"); ?></span>
		</a>

<a href="">
			Lorem ipsum dolar sit amet<br/>
			<span>this is small news content of the full news post, 
			<?php echo date("Y/m/d"); ?></span>
		</a>

<a href="">
			Lorem ipsum dolar sit amet<br/>
			<span>this is small news content of the full news post, 
			<?php echo date("Y/m/d"); ?></span>
		</a>

 		
		
	</p>
</div>
